signed weighted directed conversational graphs
------------------------------------------------
Available attributes:
- Graph:
  - label: class of the graph (or rather, its targeted message), either 0 (Non abusive) or 1 (Abusive).
  - gname: string representing the graph, used internally.
  - i: ID of the graph, used internally.
  - target_uid: user ID of the author of the targeted message (the graph is built around this message). Similar - Vertices: each vertex represents a user
  - name: arbitrary numbering, unique for each user in the dataset. Similar to attribute userid in v1.0.
to target_userid in v1.0.
- Edges: each edge represent some exchange of messages between two users
  - weight: a float value representing the intensity of the message exchanges between the users.
  - sign: polarity of the exchanged messages (positive or negative).
