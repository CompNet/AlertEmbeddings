The `figures` folder contains some plots used in the papers that use these datasets.

The networks are located in the `signed` and `unsigned` folders.
See the `readme.txt` files inside these folders, to get a description of the available graph/vertex/edge attributes.
